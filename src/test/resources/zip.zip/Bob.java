/**
* 	Hello world.
*/
class Bob {}